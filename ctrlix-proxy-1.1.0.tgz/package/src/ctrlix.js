#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const readline = require('readline');
const { CodexProxy } = require('./index.js');

const BASE_DIR = path.join(process.env.HOME || process.env.USERPROFILE, '.ctrlix');
const ACCOUNTS_DIR = path.join(BASE_DIR, 'accounts');
const CODEX_AUTH_FILE = path.join(process.env.HOME || process.env.USERPROFILE, '.codex', 'auth.json');
const ACTIVE_ACCOUNT_FILE = path.join(BASE_DIR, 'active_account');
const CONFIG_FILE = path.join(BASE_DIR, 'config.json');
const CODEX_BIN = '/Applications/Codex.app/Contents/Resources/codex';

// ANSI colors
const c = {
    rst: "\x1b[0m", br: "\x1b[1m", cy: "\x1b[36m", gr: "\x1b[32m", ye: "\x1b[33m", re: "\x1b[31m", ma: "\x1b[35m", gray: "\x1b[90m"
};

let proxyInstance = null;
let currentPort = 8888;

function ensureDirs() {
    if (!fs.existsSync(ACCOUNTS_DIR)) {
        fs.mkdirSync(ACCOUNTS_DIR, { recursive: true });
        if (fs.existsSync(CODEX_AUTH_FILE)) {
            const defaultPath = path.join(ACCOUNTS_DIR, 'default.json');
            fs.copyFileSync(CODEX_AUTH_FILE, defaultPath);
            setActiveAccount('default');
        }
    }
    if (fs.existsSync(CONFIG_FILE)) {
        try {
            const config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
            if (config.port) currentPort = parseInt(config.port) || 8888;
        } catch (e) { }
    }
}

function saveConfig() {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify({ port: currentPort }), 'utf8');
}

function getActiveAccount() {
    if (fs.existsSync(ACTIVE_ACCOUNT_FILE)) {
        return fs.readFileSync(ACTIVE_ACCOUNT_FILE, 'utf8').trim();
    }
    return null;
}

function setActiveAccount(name) {
    fs.writeFileSync(ACTIVE_ACCOUNT_FILE, name, 'utf8');
}

function getAccountList() {
    if (!fs.existsSync(ACCOUNTS_DIR)) return [];
    return fs.readdirSync(ACCOUNTS_DIR).filter(f => f.endsWith('.json')).map(f => f.replace('.json', ''));
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: `${c.ma}ctrlix> ${c.rst}`
});

function question(query) {
    return new Promise(resolve => rl.question(query, resolve));
}

function getVisibleLength(str) {
    return str.replace(/\x1b\[[0-9;]*m/g, '').length;
}

function printWelcome() {
    const active = getActiveAccount() || "None";
    const statusText = proxyInstance ? `RUNNING (Port ${currentPort})` : `STOPPED`;
    const statusColor = proxyInstance ? c.gr : c.re;

    const BOX_WIDTH = 60;

    const centerLine = (content) => {
        const visibleLength = getVisibleLength(content);
        const totalPadding = BOX_WIDTH - visibleLength;
        const leftPaddingSize = Math.floor(totalPadding / 2);
        const rightPaddingSize = totalPadding - leftPaddingSize;
        console.log(`${c.cy}│${c.rst} ${" ".repeat(leftPaddingSize)}${content}${" ".repeat(rightPaddingSize)} ${c.cy}│${c.rst}`);
    };

    console.log(`${c.cy}╭${"─".repeat(BOX_WIDTH + 2)}╮${c.rst}`);
    console.log(`${c.cy}│${" ".repeat(BOX_WIDTH + 2)}│${c.rst}`);

    centerLine(`${c.br}${c.ye}🌟 CTRLIX PROXY CLI v1.0.0 🌟${c.rst}`);
    console.log(`${c.cy}│${" ".repeat(BOX_WIDTH + 2)}│${c.rst}`);
    centerLine(`${c.rst}Proxy Manager for ChatGPT Plus / GPT-5`);
    console.log(`${c.cy}│${" ".repeat(BOX_WIDTH + 2)}│${c.rst}`);

    centerLine(`${c.gr}Status: ${c.rst}${statusColor}${statusText}${c.rst}`);
    console.log(`${c.cy}│${" ".repeat(BOX_WIDTH + 2)}│${c.rst}`);
    centerLine(`${c.gr}Active Account: ${c.rst}${active}`);

    console.log(`${c.cy}│${" ".repeat(BOX_WIDTH + 2)}│${c.rst}`);
    console.log(`${c.cy}╰${"─".repeat(BOX_WIDTH + 2)}╯${c.rst}`);
    console.log(`Type ${c.ye}/help${c.rst} for commands.`);
}

function printHelp() {
    console.log(`\n${c.br}Available Commands:${c.rst}`);
    console.log(`  ${c.gr}/start${c.rst}      - Start the Proxy server (default port ${currentPort})`);
    console.log(`  ${c.gr}/stop${c.rst}       - Stop the Proxy server`);
    console.log(`  ${c.gr}/port${c.rst}       - Set server port`);
    console.log(`  ${c.gr}/add${c.rst}        - Open browser to login a new account`);
    console.log(`  ${c.gr}/accounts${c.rst}   - List all saved accounts`);
    console.log(`  ${c.gr}/switch${c.rst}     - Select an account to use`);
    console.log(`  ${c.gr}/remove${c.rst}     - Select an account to delete`);
    console.log(`  ${c.gr}/help${c.rst}       - Show this help list`);
    console.log(`  ${c.gr}/exit${c.rst}       - Quit the program`);
    console.log();
}

async function handleAction(input) {
    const args = input.trim().split(/\s+/);
    const cmd = args[0];

    switch (cmd) {
        case '/help':
            printHelp();
            break;
        case '/start':
            if (proxyInstance) {
                console.log(`${c.ye}[!] Server is already running on port ${currentPort}.${c.rst}`);
                break;
            }
            const activeServer = getActiveAccount();
            if (!activeServer) {
                console.log(`${c.re}❌ No active account. Use /add to login.${c.rst}`);
                break;
            }
            proxyInstance = new CodexProxy({
                port: currentPort,
                authPath: path.join(ACCOUNTS_DIR, `${activeServer}.json`)
            });
            try {
                const url = await proxyInstance.start();
                console.log(`${c.gr}✅ CTRLIX server started: ${c.br}${url}/v1${c.rst}`);
                console.log(`${c.gray}(Use /stop to stop it)${c.rst}`);
            } catch (e) {
                console.log(`${c.re}❌ Error: ${e.message}${c.rst}`);
                proxyInstance = null;
            }
            break;
        case '/stop':
            if (!proxyInstance) {
                console.log(`${c.ye}[!] Server is not running.${c.rst}`);
                break;
            }
            await proxyInstance.stop();
            proxyInstance = null;
            console.log(`${c.ye}🛑 Server stopped.${c.rst}`);
            break;
        case '/port':
            const newPortStr = await question(`${c.cy}Enter new port (current ${currentPort}): ${c.rst}`);
            const p = parseInt(newPortStr);
            if (isNaN(p) || p < 1024 || p > 65535) {
                console.log(`${c.re}❌ Invalid port (1024-65535).${c.rst}`);
            } else {
                currentPort = p;
                saveConfig();
                console.log(`${c.gr}✅ Port changed to: ${currentPort}. (Applied on /start)${c.rst}`);
            }
            break;
        case '/add':
            if (!fs.existsSync(CODEX_BIN)) {
                console.log(`${c.re}❌ Codex core binary not found. Please install the Codex Desktop app first.${c.rst}`);
                break;
            }
            console.log(`${c.ye}🔄 Opening browser for login. Please complete the process on the web page...${c.rst}`);
            try {
                if (fs.existsSync(CODEX_AUTH_FILE)) fs.unlinkSync(CODEX_AUTH_FILE);
                execSync(`"${CODEX_BIN}" login`, { stdio: 'inherit' });
            } catch (e) { }

            if (fs.existsSync(CODEX_AUTH_FILE)) {
                try {
                    const authData = JSON.parse(fs.readFileSync(CODEX_AUTH_FILE, 'utf8'));
                    let accountName = 'unnamed_account';
                    const idToken = authData.tokens?.id_token;
                    if (idToken) {
                        const payloadBase64 = idToken.split('.')[1];
                        const payload = JSON.parse(Buffer.from(payloadBase64, 'base64').toString());
                        if (payload.email) {
                            accountName = payload.email.replace(/[@.]/g, '_');
                        } else if (payload.sub) {
                            accountName = payload.sub.split('|').pop();
                        }
                    }

                    fs.copyFileSync(CODEX_AUTH_FILE, path.join(ACCOUNTS_DIR, `${accountName}.json`));
                    setActiveAccount(accountName);
                    console.log(`\n${c.gr}✅ Login successful!${c.rst}`);
                    console.log(`${c.gr}✅ Account automatically saved as: ${c.br}${accountName}${c.rst}`);
                } catch (parseError) {
                    const fallbackName = `account_${Date.now()}`;
                    fs.copyFileSync(CODEX_AUTH_FILE, path.join(ACCOUNTS_DIR, `${fallbackName}.json`));
                    setActiveAccount(fallbackName);
                    console.log(`${c.gr}✅ Login successful (Saved as temporary name: ${fallbackName})${c.rst}`);
                }
            } else {
                console.log(`${c.re}❌ No login data found after closing the browser.${c.rst}`);
            }
            break;
        case '/accounts':
            const list = getAccountList();
            const current = getActiveAccount();
            if (list.length === 0) {
                console.log("📂 No accounts found.");
            } else {
                console.log(`\n${c.br}📂 Account List:${c.rst}`);
                list.forEach((acc, i) => {
                    const mark = acc === current ? `${c.gr}➜${c.rst}` : " ";
                    console.log(`  ${mark} [${i + 1}] ${acc}`);
                });
                console.log();
            }
            break;
        case '/switch':
            const sList = getAccountList();
            if (sList.length === 0) {
                console.log(`${c.re}❌ No accounts available to select.${c.rst}`);
                break;
            }
            console.log(`\n${c.cy}Select account to switch:${c.rst}`);
            sList.forEach((acc, i) => console.log(`  [${i + 1}] ${acc}`));
            const sIdx = await question(`${c.ma}Enter number: ${c.rst}`);
            const idx = parseInt(sIdx) - 1;
            if (sList[idx]) {
                setActiveAccount(sList[idx]);
                console.log(`${c.gr}✅ Switched to: ${sList[idx]}${c.rst}`);
                if (proxyInstance) console.log(`${c.ye}[!] Note: Restart server (/stop and /start) to apply new account.${c.rst}`);
            } else {
                console.log(`${c.re}❌ Invalid selection.${c.rst}`);
            }
            break;
        case '/remove':
            const rList = getAccountList();
            if (rList.length === 0) {
                console.log(`${c.re}❌ No accounts available to delete.${c.rst}`);
                break;
            }
            console.log(`\n${c.re}Select account to remove:${c.rst}`);
            rList.forEach((acc, i) => console.log(`  [${i + 1}] ${acc}`));
            const rIdxStr = await question(`${c.ma}Enter number: ${c.rst}`);
            const rIdx = parseInt(rIdxStr) - 1;
            if (rList[rIdx]) {
                const accName = rList[rIdx];
                fs.unlinkSync(path.join(ACCOUNTS_DIR, `${accName}.json`));
                console.log(`${c.gr}✅ Account removed: ${accName}${c.rst}`);
                if (getActiveAccount() === accName) {
                    const remaining = getAccountList();
                    if (remaining.length > 0) setActiveAccount(remaining[0]);
                    else if (fs.existsSync(ACTIVE_ACCOUNT_FILE)) fs.unlinkSync(ACTIVE_ACCOUNT_FILE);
                }
            } else {
                console.log(`${c.re}❌ Invalid selection.${c.rst}`);
            }
            break;
        case '/exit':
            console.log("👋 Bye!");
            process.exit(0);
        default:
            if (input.startsWith('/')) {
                console.log(`${c.re}❌ Unknown command. Type /help to see the list.${c.rst}`);
            }
    }
}

async function main() {
    ensureDirs();
    printWelcome();
    rl.prompt();
    rl.on('line', async (line) => {
        await handleAction(line.trim());
        rl.prompt();
    });
}

main();
