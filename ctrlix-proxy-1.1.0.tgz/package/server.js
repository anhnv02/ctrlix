#!/usr/bin/env node

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 8888;
const CODEX_AUTH_PATH = path.join(process.env.HOME || process.env.USERPROFILE, '.codex', 'auth.json');

function getToken() {
    try {
        const data = JSON.parse(fs.readFileSync(CODEX_AUTH_PATH, 'utf8'));
        return data.tokens?.access_token || data.OPENAI_API_KEY;
    } catch (err) {
        return null;
    }
}

const server = http.createServer(async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*');

    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }

    const url = new URL(req.url, `http://${req.headers.host}`);

    if (req.method === 'GET' && (url.pathname === '/models' || url.pathname === '/v1/models')) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            object: 'list',
            data: [
                { id: 'gpt-5', object: 'model', created: 1687882411, owned_by: 'openai' },
                { id: 'gpt-4o', object: 'model', created: 1687882411, owned_by: 'openai' },
            ]
        }));
        return;
    }

    if (req.method === 'POST' && (url.pathname === '/chat/completions' || url.pathname === '/v1/chat/completions')) {
        let bodyStr = '';
        req.on('data', chunk => { bodyStr += chunk.toString(); });
        req.on('end', async () => {
            try {
                let payload;
                try {
                    payload = JSON.parse(bodyStr);
                } catch (e) {
                    res.writeHead(400); res.end('Invalid JSON'); return;
                }

                const token = getToken();
                if (!token) {
                    res.writeHead(401, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ error: { message: 'Missing Codex auth token. Please login in Codex App first.', type: 'invalid_request_error' } }));
                    return;
                }

                const isStreaming = payload.stream === true;
                const inputs = (payload.messages || []).map(msg => {
                    let text = typeof msg.content === 'string' ? msg.content : JSON.stringify(msg.content);
                    return {
                        type: 'message',
                        role: msg.role,
                        content: [{ type: 'input_text', text: text }]
                    };
                });

                const codexReq = {
                    model: payload.model || "gpt-5",
                    instructions: "You are a helpful AI assistant.",
                    input: inputs,
                    store: false,
                    stream: true
                };

                const response = await fetch('https://chatgpt.com/backend-api/codex/responses', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token,
                        'User-Agent': 'Codex Desktop/26.224.1209 (darwin; arm64)',
                        'Accept': 'text/event-stream'
                    },
                    body: JSON.stringify(codexReq)
                });

                if (!response.ok) {
                    res.writeHead(response.status, { 'Content-Type': 'application/json' });
                    const errorText = await response.text();
                    res.end(JSON.stringify({ error: { message: `Upstream error: ${errorText}`, type: 'upstream' } }));
                    return;
                }

                const completionId = "chatcmpl-" + crypto.randomUUID();
                const created = Math.floor(Date.now() / 1000);

                if (isStreaming) {
                    res.writeHead(200, {
                        'Content-Type': 'text/event-stream',
                        'Cache-Control': 'no-cache',
                        'Connection': 'keep-alive'
                    });

                    res.write(`data: ${JSON.stringify({
                        id: completionId, object: 'chat.completion.chunk', created, model: payload.model,
                        choices: [{ index: 0, delta: { role: 'assistant' }, finish_reason: null }]
                    })}\n\n`);

                    const reader = response.body.getReader();
                    const decoder = new TextDecoder("utf-8");
                    let buffer = '';

                    while (true) {
                        const { done, value } = await reader.read();
                        if (done) break;
                        buffer += decoder.decode(value, { stream: true });
                        let lines = buffer.split('\n');
                        buffer = lines.pop();

                        for (const line of lines) {
                            if (line.startsWith('data: ')) {
                                const dataRaw = line.slice(6).trim();
                                if (dataRaw === '[DONE]') continue;
                                try {
                                    const evt = JSON.parse(dataRaw);
                                    if (evt.type === 'response.output_text.delta') {
                                        res.write(`data: ${JSON.stringify({
                                            id: completionId, object: 'chat.completion.chunk', created, model: payload.model,
                                            choices: [{ index: 0, delta: { content: evt.delta }, finish_reason: null }]
                                        })}\n\n`);
                                    } else if (evt.type === 'response.completed') {
                                        res.write(`data: ${JSON.stringify({
                                            id: completionId, object: 'chat.completion.chunk', created, model: payload.model,
                                            choices: [{ index: 0, delta: {}, finish_reason: 'stop' }]
                                        })}\n\n`);
                                    }
                                } catch (e) { }
                            }
                        }
                    }
                    res.write('data: [DONE]\n\n');
                    res.end();
                } else {
                    let fullText = '';
                    const reader = response.body.getReader();
                    const decoder = new TextDecoder("utf-8");
                    let buffer = '';
                    while (true) {
                        const { done, value } = await reader.read();
                        if (done) break;
                        buffer += decoder.decode(value, { stream: true });
                        let lines = buffer.split('\n');
                        buffer = lines.pop();
                        for (const line of lines) {
                            if (line.startsWith('data: ')) {
                                const dataRaw = line.slice(6).trim();
                                if (dataRaw === '[DONE]') continue;
                                try {
                                    const evt = JSON.parse(dataRaw);
                                    if (evt.type === 'response.output_text.delta') {
                                        fullText += evt.delta;
                                    }
                                } catch (e) { }
                            }
                        }
                    }
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({
                        id: completionId,
                        object: "chat.completion",
                        created,
                        model: payload.model || "gpt-5",
                        choices: [{
                            index: 0,
                            message: { role: "assistant", content: fullText },
                            finish_reason: "stop"
                        }],
                        usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
                    }));
                }
            } catch (e) {
                console.error(e);
                res.writeHead(500);
                res.end(JSON.stringify({ error: { message: e.toString() } }));
            }
        });
        return;
    }

    res.writeHead(404);
    res.end('Not Found');
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`[🚀] Standalone Codex Proxy is running -> http://0.0.0.0:${PORT}`);
    console.log(`[✓] Reading tokens automatically from: ${CODEX_AUTH_PATH}`);
    console.log(`
  API Base: http://127.0.0.1:${PORT}/v1
  Model: gpt-5 (hoặc gpt-4o)
  API Key: bat-ky-chuoi-nao
`);
});
