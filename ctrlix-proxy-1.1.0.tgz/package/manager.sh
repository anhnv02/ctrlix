#!/usr/bin/env bash

# Config
CODEX_BIN="/Applications/Codex.app/Contents/Resources/codex"
AUTH_FILE="$HOME/.codex/auth.json"
ACCOUNTS_DIR="$HOME/.codex/accounts"

# Create accounts dir if not exists
mkdir -p "$ACCOUNTS_DIR"

show_help() {
    echo "======================================"
    echo "   Codex Account Manager (Proxy)     "
    echo "======================================"
    echo "Usage: ./manager.sh [action] [name]"
    echo ""
    echo "Actions:"
    echo "  login <name>    - Đăng nhập tài khoản mới và lưu với tên <name>"
    echo "                    VD: ./manager.sh login work_acc"
    echo "  list            - Liệt kê các tài khoản đã lưu"
    echo "  switch <name>   - Chuyển sang dùng tài khoản <name>"
    echo "                    VD: ./manager.sh switch personal_acc"
    echo "  status          - Kiểm tra tài khoản đang dùng hiện tại"
    echo "======================================"
}

if [ -z "$1" ] || [ "$1" == "help" ]; then
    show_help
    exit 0
fi

if [ ! -f "$CODEX_BIN" ]; then
    echo "❌ Không tìm thấy Codex binary tại: $CODEX_BIN"
    echo "Vui lòng giữ lại file này trên máy để có module login."
    exit 1
fi

case "$1" in
    "login")
        if [ -z "$2" ]; then
            echo "❌ Bạn cần đặt tên cho tài khoản này (VD: login work)"
            exit 1
        fi
        ACC_NAME="$2"
        echo "🔄 Đang mở trình duyệt đăng nhập cho tài khoản: $ACC_NAME..."
        
        # Logout first to clear old session
        "$CODEX_BIN" logout > /dev/null 2>&1
        
        # Interactive login
        "$CODEX_BIN" login
        
        if [ -f "$AUTH_FILE" ]; then
            cp "$AUTH_FILE" "$ACCOUNTS_DIR/$ACC_NAME.json"
            echo "✅ Lưu thông tin đăng nhập thành công vào hồ sơ: $ACC_NAME"
        else
            echo "❌ Đăng nhập bị huỷ hoặc có lỗi."
        fi
        ;;

    "list")
        echo "📂 Danh sách các tài khoản đang lưu:"
        echo "------------------------------------"
        count=0
        for f in "$ACCOUNTS_DIR"/*.json; do
            if [ -f "$f" ]; then
                name=$(basename "$f" .json)
                
                # Check current
                current=""
                if [ -f "$AUTH_FILE" ] && cmp -s "$f" "$AUTH_FILE"; then
                   current=" (Đang dùng ✨)"
                fi
                
                echo " - $name$current"
                count=$((count + 1))
            fi
        done
        if [ "$count" -eq 0 ]; then
             echo "(Chưa có tài khoản nào)"
        fi
        ;;

    "switch")
        if [ -z "$2" ]; then
            echo "❌ Bạn cần nhập tên tài khoản muốn đổi (VD: switch work)"
            exit 1
        fi
        ACC_NAME="$2"
        PROFILE_PATH="$ACCOUNTS_DIR/$ACC_NAME.json"
        
        if [ -f "$PROFILE_PATH" ]; then
            mkdir -p "$HOME/.codex"
            cp "$PROFILE_PATH" "$AUTH_FILE"
            echo "✅ Đã chuyển đổi thành công sang tài khoản: $ACC_NAME"
            echo "Proxy sẽ tự động dùng Tokens này ở lần Request tiếp theo!"
        else
            echo "❌ Không tìm thấy tài khoản tên: $ACC_NAME"
        fi
        ;;

    "status")
        echo "🔍 Trạng thái:"
        "$CODEX_BIN" login status
        ;;

    *)
        echo "Lệnh không hợp lệ!"
        show_help
        ;;
esac
