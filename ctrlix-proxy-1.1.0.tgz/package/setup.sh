#!/usr/bin/env bash

echo "🚀 Bắt đầu cài đặt Codex API Proxy for Continue.dev/CLINE..."

# Kiểm tra Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Không tìm thấy Node.js. Vui lòng cài đặt Node.js từ https://nodejs.org/"
    exit 1
fi

NODE_VER=$(node -v | cut -d 'v' -f 2 | cut -d '.' -f 1)
if [ "$NODE_VER" -lt 18 ]; then
    echo "❌ Yêu cầu Node.js phiên bản 18 trở lên (hiện tại là $NODE_VER). Vui lòng cập nhật."
    exit 1
fi

echo "✅ Đã tìm thấy Node.js phiên bản $NODE_VER"

PROXY_DIR="$HOME/.codex-super-proxy"
mkdir -p "$PROXY_DIR"

# Copy source file into proxy dir
cp server.js "$PROXY_DIR/server.js"
chmod +x "$PROXY_DIR/server.js"

# Create launch script
cat << 'EOF' > "$PROXY_DIR/start.sh"
#!/bin/bash
node "$HOME/.codex-super-proxy/server.js"
EOF
chmod +x "$PROXY_DIR/start.sh"

echo "✅ Cài đặt hoàn tất vào $PROXY_DIR"
echo ""
echo "============================================"
echo "    CÁC BƯỚC SỬ DỤNG:"
echo "============================================"
echo "1. Đảm bảo bạn đã từng mở app OpenAI Codex trên máy tính để đăng nhập ít nhất 1 lần (để có ~/.codex/auth.json)."
echo "2. Chạy lệnh sau để bật Proxy:"
echo "   $PROXY_DIR/start.sh"
echo ""
echo "3. Cấu hình Continue.dev config.json:"
echo "   \"models\": [{"
echo "       \"title\": \"Codex GPT-5\","
echo "       \"provider\": \"openai\","
echo "       \"model\": \"gpt-5\","
echo "       \"apiBase\": \"http://127.0.0.1:8888/v1\","
echo "       \"apiKey\": \"dummy\""
echo "   }]"
echo "============================================"
